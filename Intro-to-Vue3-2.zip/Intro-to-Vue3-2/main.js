const app = Vue.createApp({
  data: function () {
    return {
      product: "Socks",
      image: "./assets/images/socks_blue.jpg",
    };
  },
});
